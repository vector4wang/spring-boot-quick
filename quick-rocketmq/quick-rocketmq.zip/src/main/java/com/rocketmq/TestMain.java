package com.rocketmq;

import java.util.UUID;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/12/5
 * Time: 20:18
 * Description:
 */
public class TestMain {
    public static void main(String[] args) {
        System.out.println(UUID.randomUUID().toString());
    }
}
